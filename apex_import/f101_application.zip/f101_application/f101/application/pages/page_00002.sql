prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>10107082786587856
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'MLOPSU1'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(10280820922164845)
,p_name=>'Dashboard'
,p_alias=>'DASHBOARD'
,p_step_title=>'Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://dsdashboardv1-apaccpt03-ia.analytics.ocp.oraclecloud.com/public/dv/v1/embedding/standalone/embedding.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(window).on("theme42ready", function()',
'    {',
'        if ($("body").hasClass("js-navExpanded"))',
'        {',
'            $("#t_Button_navControl").click();',
'        }',
'    }',
');'))
,p_page_template_options=>'#DEFAULT#'
,p_browser_cache=>'N'
,p_last_updated_by=>'MLOPSU1'
,p_last_upd_yyyymmddhh24miss=>'20211116105209'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10313091590165027)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10200658791164714)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(10133634643164629)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(10257757235164779)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12219860630431020)
,p_plug_name=>'MLOps Accuracy Monitoring'
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10191261649164709)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style=''height:900px; width: 100%''>',
'<oracle-dv project-path="/@Catalog/shared/MLOps_V1/MLOps_V3">',
'</oracle-dv>',
'</div>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
