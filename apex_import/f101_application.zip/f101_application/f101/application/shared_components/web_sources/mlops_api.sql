prompt --application/shared_components/web_sources/mlops_api
begin
--   Manifest
--     WEB SOURCE: MLOPS-API
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>10107082786587856
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'MLOPSU1'
);
wwv_flow_api.create_web_source_module(
 p_id=>wwv_flow_api.id(11283963282462803)
,p_name=>'MLOPS-API'
,p_static_id=>'MLOPS_API'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_api.id(11282810272462773)
,p_remote_server_id=>wwv_flow_api.id(11282619029462769)
,p_url_path_prefix=>'/ocid1.datasciencemodeldeployment.oc1.iad.amaaaaaap77apcqXXXXXXXXXXXXXXXXXXXXXXXXXXXXX6tkckylaa/predict'
,p_credential_id=>wwv_flow_api.id(11082852914551962)
,p_sync_table_owner=>'MLOPSU1'
,p_sync_table_name=>'OUTCOME'
,p_sync_max_http_requests=>1000
);
wwv_flow_api.create_web_source_operation(
 p_id=>wwv_flow_api.id(11284155512462818)
,p_web_src_module_id=>wwv_flow_api.id(11283963282462803)
,p_operation=>'POST'
,p_database_operation=>'FETCH_SINGLE_ROW'
,p_url_pattern=>'.'
,p_request_body_template=>'{"CUSTOMER_VALUE_SEGMENT":{"4":"Bronze"},"NUMBER_OF_SAVING_ACCOUNTS":{"4":0.0},"CHURN_RATE_OF_ACCOUNT_NON":{"4":0.85},"FACEBOOK_INFLUENCE_SCORE":{"4":0.4},"HIGHEST_CREDIT_CARD_LIMIT":{"4":8250.0},"MARITAL_STATUS":{"4":"Married"},"NUMBER_OF_CURRENT_AC'
||'COUNTS":{"4":3.0},"NUMBER_OF_CLOSED_ACCOUNTS":{"4":2.0},"LOAN_LENGTH":{"4":12.0},"LIFECYCLE_STAGE":{"4":3.0},"CREDIT_HISTORY":{"4":"Risky"},"PERCENTAGE_UG":{"4":11.0},"HAS_CHECKING_ACCOUNT":{"4":"No"},"NO_OF_DEBTORS_ON_FB":{"4":3.0},"NO_OF_FOLLOWERS_'
||'ON_TWITTER":{"4":53.0},"LOAN_TYPE":{"4":"Need"},"FIXED_INCOME_RATE":{"4":0.9},"CHURN_RATE_OF_ACCOUNT_NO1":{"4":1.0},"MODE_JOB_OF_CONTACTS":{"4":"Law"},"EDUCATION_LEVEL":{"4":"Bachelor''s Degree"},"CUSTOMER_DMG_SEGMENT":{"4":"Segment4"},"RESIDENTAL_STA'
||'TUS":{"4":"Tenant"},"IS_FOREIGN_WORKER":{"4":"No"},"DELINQUENCY_STATUS":{"4":"Normal"},"CHURN_RATE__OF_ACCOUNT_NO2":{"4":0.7},"JOB_FRIENDS_PERCENTAGE":{"4":0.2},"REGION":{"4":"Central Anatolia"},"NO_OF_LINKEDIN_CONTACTS":{"4":23.0},"MOTHERS_JOB":{"4"'
||':"Retired"},"CURRENT_ADDRESS_DURATION":{"4":78.0},"CHURN_RATE_OF_CC2":{"4":0.3},"CITY_SIZE":{"4":"Medium"},"PERCENTAGE_OTHER":{"4":77.0},"CHURN_RATE_OF_CC1":{"4":0.8},"MOST_POPULAR_POST_CATEGORY":{"4":"Education"},"NUMBER_OF_PROTESTOR_LIKES":{"4":2.0'
||'},"WEALTH":{"4":"Poor"},"HAS_COLLATERAL":{"4":"Yes"},"HEALTH_SCORE":{"4":6.0},"LOAN_AMOUNT":{"4":30000.0},"MAX_CC_SPENT_AMOUNT":{"4":5775.0},"SCHOOL_FRIENDS_PERCENTAGE":{"4":0.5},"NUMBER_OF_OPEN_ACCOUNTS":{"4":2.0},"NO_OF_TOTAL_ENDORSEMENTS":{"4":2.0'
||'},"IS_POSTED_STH_WITHIN_A_MONTH":{"4":"Yes"},"MAX_CC_SPENT_AMOUNT_PREV":{"4":825.0},"NEW_BANKRUPTCY":{"4":"Unknown"},"THIRD_MOST_SPENDING_TYPE":{"4":"Bills"},"AVERAGE_NO_OF_RETWEETS":{"4":5.0},"CHURN_RATE_OF_CCN":{"4":0.55},"CUSTOMER_DEPTH":{"4":1.0}'
||',"GENDER":{"4":"Female"},"NO_OF_PROTESTOR_COMMENTS":{"4":0.0},"PERCENTAGE_MASTERS":{"4":1.0},"NUMBER_OF_PRIOR_LOANS":{"4":3.0},"HAS_SAME_PHONE_NO_SINCE":{"4":15.0},"PERCENTAGE_HIGH_SCHOOL":{"4":0.0},"HAS_OWN_PHONE_NO":{"4":"No"},"AGE":{"4":47.0},"MOS'
||'T_SPENDING_TYPE":{"4":"Eating and Drinking"},"TENURE":{"4":6.0},"NUMBER_OF_COLLECTIONS":{"4":0.0},"FATHERS_JOB":{"4":"Retired"},"SECOND_MOST_SPENDING_TYPE":{"4":"Transportation"},"AVERAGE_JOB_CHANGING_PERIOD":{"4":27.0},"PRESENT_EMPLOYMENT_SINCE":{"4'
||'":"Less Than Seven Years"},"CREDIT_CARD_UTILIZATION_RATE":{"4":0.8},"FAMILY_SIZE":{"4":4.0},"DEBTOR_GUARANTORS":{"4":"Co Applicant"},"PERCENTAGE_PHD_ON_LINKEDIN":{"4":11.0},"NO_OF_RECRUITERS_ON_LINKEDIN":{"4":0.0},"NUMBER_OF_INACTIVE_ACCOUNTS":{"4":1'
||'.0},"NUMBER_OF_INQUIRIES":{"4":1.0},"OCCUPATION":{"4":"Worker"}}'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_api.create_web_source_operation(
 p_id=>wwv_flow_api.id(11604616378665036)
,p_web_src_module_id=>wwv_flow_api.id(11283963282462803)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
);
wwv_flow_api.component_end;
end;
/
