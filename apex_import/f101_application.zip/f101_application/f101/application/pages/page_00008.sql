prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>10107082786587856
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'MLOPSU1'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(10280820922164845)
,p_name=>'Thank You'
,p_alias=>'THANK-YOU'
,p_step_title=>'Thank You'
,p_welcome_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script src="#APP_IMAGES#scripts/settings.js"></script>',
'<script src="#APP_IMAGES#scripts/web-sdk.js" onload="initSDK(''Bots'')"></script>'))
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oda-chat-button {',
'    // height:  76px;',
'    // width:   64px;',
'    outline: none;',
'    background-color: transparent;',
'    box-shadow: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'MLOPSU1'
,p_last_upd_yyyymmddhh24miss=>'20211111043749'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(11755303301263226)
,p_plug_name=>'Thank you &APP_USER.,  for choosing us. '
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--success'
,p_plug_template=>wwv_flow_api.id(10156569663164677)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(13053731353000901)
,p_plug_name=>'What''s Next'
,p_parent_plug_id=>wwv_flow_api.id(11755303301263226)
,p_region_template_options=>'#DEFAULT#:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10191261649164709)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>'Your loan is approved in principle. Our loan officer will contact you shortly to arrange loan disbursement.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
